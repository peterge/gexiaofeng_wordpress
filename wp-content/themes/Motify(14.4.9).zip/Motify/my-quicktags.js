        QTags.addButton( 'pre.html4', 'pre.html4', "\n<pre lang='html4strict'>\n", "\n</pre>\n" );
        QTags.addButton( 'pre.js', 'pre.js', "\n<pre lang='javascript'>\n", "\n</pre>\n" );
        QTags.addButton( 'pre.php', 'pre.php', "\n<pre lang='php'>\n", "\n</pre>\n" );		
		QTags.addButton( '[gallery.i2m]', '[gallery.i2m]', '\n[gallery link="file" include="," columns="2" size="medium"]\n','' );
		QTags.addButton( '[gallery.i3m]', '[gallery.i3m]', '\n[gallery link="file" include=","  size="medium"]\n','' );
        QTags.addButton( '<', '<', '&lt;', '' );
        QTags.addButton( '>', '>', '&gt;', '' );