		</div>
    </div>
</div>
<footer id="footer">
	<div class="container">
		&copy; <?php echo date('Y'); ?> <a href="<?php bloginfo('url'); ?>"><?php bloginfo('name'); ?></a>.
		<?php _e('由 <a href="http://wordpress.org">Wordpress</a> 强力驱动. 模板由<a href="http://pagecho.com">cho</a>制作'); ?>.
	</div>
</footer>
<?php wp_footer();?>
</body>
</html>